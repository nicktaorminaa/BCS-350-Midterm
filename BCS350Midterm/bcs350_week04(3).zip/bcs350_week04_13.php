<?php
// BCS350_week04_10 - Week 4, Output the Phonebook Table - Update Link
// Written by:  Prof. Kaplan, Sept. 2016

// Variables
  $pgm 			= "bcs350_week04_13.php";
  $pgm2			= "bcs350_week04_12.php";  
  $count 		= 0;

// Get Input
  if (isset($_POST['cat_in'])) $cat_in = $_POST['cat_in'];	else $cat_in = "All";
  if ($cat_in == "All")
	$filter = NULL;
	else $filter = "WHERE category='$cat_in'";  


// Connect to MySQL and the BCS350 Database
  $mysqli = new mysqli('localhost', 'root', NULL, 'bcs350'); 

// Load CATEGORIES array with Unique values from Phonebook Table
  $query =  "Select DISTINCT category FROM phonebook ORDER BY category";
  $result = $mysqli->query($query);
  $categories[] = "All";
  while(list($ctgy) = $result->fetch_row())
	$categories[] = $ctgy;
  
// Query the Phonebook Table
  $query = "SELECT rowid, firstname, lastname, category, phone, email, city
			FROM phonebook
			$filter
			ORDER BY lastname, firstname";
  $result = $mysqli->query($query);
  
// Output the Results
  echo "<center><b><u>My Phonebook</u></b></center><br><br>
		<table width='1024' align='center'>
		<tr>
		<th width='24%'>Name</th>
		<th width='12%'>Category</th>
		<th width='12%'>Phone</th>
		<th width='30%'>Email</th>
		<th width='17%'>City</th>
		<th width='5%'>&nbsp;</th>
		</tr>";
  while(list($rowid, $firstname, $lastname, $category, $phone, $email, $city) = $result->fetch_row()) {
    $count++;
	echo "<tr>
		  <td><a href='mailto:$email'>$firstname $lastname</a></td>
		  <td>$category</td>
		  <td>$phone</td>
		  <td>$email</td>
		  <td>$city</td>
		  <td><a href='$pgm2?r=$rowid'><button>UPDATE</button></a></td>
		  </tr>";
	}
  echo "</table><br>
		<table width='1024' align='center'>
		<tr><td>$count PhoneBook Entries Found</td></tr>
		<tr><td>&nbsp;</td></tr>
		<tr><td><form action='$pgm' method='post'>
		CATEGORY: <select name='cat_in'>";
  foreach ($categories as $cat) {
	  if ($cat == $cat_in) $se = "SELECTED";	else $se = NULL;
	  echo "<option $se>$cat</option>";
	  }
  echo "</select>
		<input type='submit' name='submit' value='Submit'>
		</form></td></tr></table>";  
?>