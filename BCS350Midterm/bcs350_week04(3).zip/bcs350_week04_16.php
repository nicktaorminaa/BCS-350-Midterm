<?php
// BCS350_week04_16 - Week 4, Select a Name from the Phonebook for Update
// Written by:  Prof. Kaplan, Sept. 2021

// Variables
	$pgm			= 'bcs350_week04_12.php';  

// Connect to MySQL and the BCS350 Database
	$mysqli = mysqli_connect('localhost', 'root', NULL, 'bcs350') 
		OR die('Could not connect to MySQL' . mysqli_connect_error()); 

// Query the Phonebook Table
	$query = "SELECT rowid, firstname, lastname
			  FROM phonebook
			  ORDER BY lastname, firstname";
	$result = mysqli_query($mysqli, $query);
	if (!$result) echo "QUERY ERROR [$query]: " . mysqli_error($mysqli);
  
// Output the Results
	echo "<!DOCTYPE HTML><HTML><BODY>
		  <center><b><u>Phonebook Update by Name Selection</u></b>
		  <p><form action='$pgm' method='GET'> 
		  Select a Name: <select name='r' ONCHANGE='this.form.submit()'>
		  <option>-------------------</option>\n";
		  
// Loop Through all the names		  
	while(list($rowid, $firstname, $lastname) = $result->fetch_row())
		echo "<option value='rowid'>$firstname $lastname</option>";
		
// End of Page		
	echo "</body></html>";  
?>