<?php
// BCS350_week04_11 - Week 4, Update the Phonebook Table - Update with Link to Phone List
// Written by:  Prof. Kaplan, Sept. 2016

// Variables
	$pgm		= "bcs350_week04_11.php";
	$categorys	= array("Family", "Friend", "Business", "Other");
	$msg 		= NULL;
	$color		= "black";
	
// Get Input
	if (isset($_POST['task']))		$task = $_POST['task'];				else $task = "First";
	if (isset($_GET['r']))			{$rowid = $_GET['r']; $task = "Show";}	else $rowid = NULL;
	if (isset($_POST['rowid']))		$rowid = $_POST['rowid'];
	if (isset($_POST['firstname']))	$firstname = $_POST['firstname'];	else $firstname = NULL;
	if (isset($_POST['lastname']))	$lastname = $_POST['lastname'];		else $lastname = NULL;	
	if (isset($_POST['category']))	$category = $_POST['category'];		else $category = NULL;
	if (isset($_POST['phone']))		$phone = $_POST['phone'];			else $phone = NULL;
	if (isset($_POST['email']))		$email = $_POST['email'];			else $email = NULL;	
	if (isset($_POST['city']))		$city = $_POST['city'];				else $city = NULL;
	
// Verify Input
	if (($task != "First") AND ($task != "Clear") AND ($task != "Add")) {
		if ($rowid < 1)		$msg = "Invalid ROW ID"; 
		}
	if ($msg != NULL)		$task = "Error";

// Connect to MySQL and the BCS350 Database
	$mysqli = new mysqli('localhost', 'root', NULL, 'bcs350');
	
// Execute Task
	switch($task) {
		case "Clear":		$rowid = $firstname = $lastname = $category = $phone = $email = $city = NULL;
		case "First":		$msg = "Enter ROW ID and press Submit"; break;
		case "Error":		$firstname = $lastname = $category = $phone = $email = $city = NULL; $color = "red"; break;
		case "Previous":
		case "Next":
		case "Show":		if ($task == "Previous") $rowid--;
							if ($task == "Next") $rowid++;
							$query = "SELECT firstname, lastname, category, phone, email, city FROM phonebook WHERE rowid='$rowid'";
							$result = $mysqli->query($query);
							if ($result->num_rows === 0) {
								$msg = "ROW ID $rowid NOT FOUND"; 
								$color = "red";
								$firstname = $lastname = $category = $phone = $email = $city = NULL;
								}
							else {
								list($firstname, $lastname, $category, $phone, $email, $city) = $result->fetch_row();
								$msg = "ROW ID $rowid found";
								}
							break;
		case "Update":		$query = "UPDATE phonebook SET
									  firstname	= '$firstname',
									  lastname	= '$lastname',
									  category	= '$category',
									  phone		= '$phone',
									  email		= '$email',
									  city		= '$city'
									  WHERE rowid = '$rowid'";
							$result = $mysqli->query($query);
							if ($result) $msg = "ROW ID $rowid Updated";
								else {$msg = "ROW ID $rowid NOT Updated" . mysqli_error(); $color = "red";}
		}
		
// Output the Results
	echo "<center><b><u>My Phonebook Update</u></b></center><br><br>
		  <form action='$pgm' method='post'>
		  <table width='1024' align='center'>
		  <tr><td width='10%'>ROW ID    </td><td width='90%'><input type='text' name='rowid'     value='$rowid'     size='08'></td></tr>
		  <tr><td width='10%'>First Name</td><td width='90%'><input type='text' name='firstname' value='$firstname' size='25'></td></tr>
		  <tr><td width='10%'>Last Name </td><td width='90%'><input type='text' name='lastname'  value='$lastname'  size='25'></td></tr>
		  <tr><td width='10%'>Category  </td><td width='90%'><select name='category'>";
	foreach ($categorys as $cat) {
		if ($cat == $category) $se = "SELECTED"; else $se = NULL;
		echo "<option $se>$cat</option>";
		}
	echo "</select></td></tr>
		  <tr><td width='10%'>Phone     </td><td width='90%'><input type='text' name='phone'     value='$phone'     size='15'></td></tr>
		  <tr><td width='10%'>Email     </td><td width='90%'><input type='text' name='email'     value='$email'     size='80'></td></tr>
		  <tr><td width='10%'>City      </td><td width='90%'><input type='text' name='city'      value='$city'      size='25'></td></tr>
		  </td></td></table><br>
		  <table width='1024' align='center'>
		  <tr><td align='center'>
			  <input type='submit' name='task' value='Show'>
			  <input type='submit' name='task' value='Update'>			  
			  <input type='submit' name='task' value='Clear'>
			  <input type='submit' name='task' value='Previous'>
			  <input type='submit' name='task' value='Next'>
		  </td></tr>
		  </table>
		  <table width='1024' align='center'>
		  <tr><td width='10%'>MESSAGE: </td><td width='90%'><font color='$color'>$msg</font></td></tr>
		  </table></form>
		  <table width='1024' align='center'
		  <tr><td align='center'><a href='bcs350_week04_10.php'><button>Return to Phone List</button></a></td></tr>
		  </table>";
?>