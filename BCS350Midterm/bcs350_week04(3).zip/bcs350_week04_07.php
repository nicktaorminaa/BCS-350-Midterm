<?php
// BCS350_week04_07 - Week 4, Update the Phonebook Table - Show
// Written by:  Prof. Kaplan, Sept. 2016

// Variables
	$pgm		= 'bcs350_week04_07.php';
	$categories	= array('Family', 'Friend', 'Business', 'Hobby', 'Other');
	$msg 		= NULL;
	$color		= "black";
	
// Get Input
	if (isset($_POST['task']))		$task = $_POST['task'];				else $task = "First";
	if (isset($_POST['rowid']))		$rowid = $_POST['rowid'];			else $rowid = NULL;
	if (isset($_POST['firstname']))	$firstname = $_POST['firstname'];	else $firstname = NULL;
	if (isset($_POST['lastname']))	$lastname = $_POST['lastname'];		else $lastname = NULL;	
	if (isset($_POST['category']))	$category = $_POST['category'];		else $category = NULL;
	if (isset($_POST['phone']))		$phone = $_POST['phone'];			else $phone = NULL;
	if (isset($_POST['email']))		$email = $_POST['email'];			else $email = NULL;	
	if (isset($_POST['city']))		$city = $_POST['city'];				else $city = NULL;

// Verify Input
	if ($task != "First") {
		if ($rowid < 1)		$msg = "Invalid ROW ID"; 
		}
	if ($msg != NULL)		$task = "Error";

// Connect to MySQL and the BCS350 Database
	$mysqli = new mysqli('localhost', 'root', NULL, 'bcs350');
	
// Execute Task
	switch($task) {
		case "First":		$msg = "Enter ROW ID and press Submit"; break;
		case "Error":		$firstname = $lastname = $category = $phone = $email = $city = NULL; $color = "red"; break;
		case "Previous":
		case "Next":
		case "Show":		if ($task == 'Previous') $rowid--;
							if ($task == 'Next') $rowid++;
							$query = "SELECT firstname, lastname, category, phone, email, city FROM phonebook WHERE rowid='$rowid'";
							$result = mysqli_query($mysqli, $query);
							if (mysqli_num_rows($result) === 0) {
								$msg = "ROW ID $rowid NOT FOUND"; 
								$color = "red";
								}
							else {
								list($firstname, $lastname, $category, $phone, $email, $city) = mysqli_fetch_row($result);
								$msg = "ROW ID $rowid found";
								}
							break;
		case "Clear":		$rowid = $firstname = $lastname = $category = $phone = $email = $city = NULL;
							break;
		}
		
// Output the Results
	echo "<center><b><u>My Phonebook Update</u></b></center><br><br>
		  <form action='$pgm' method='post'>
		  <table width='1024' align='center'>
		  <tr><td width='10%'>ROW ID    </td><td width='90%'><input type='text' name='rowid'     value='$rowid'     size='08'></td></tr>
		  <tr><td width='10%'>First Name</td><td width='90%'><input type='text' name='firstname' value='$firstname' size='25'></td></tr>
		  <tr><td width='10%'>Last Name </td><td width='90%'><input type='text' name='lastname'  value='$lastname'  size='25'></td></tr>
		  <tr><td width='10%'>Category  </td><td width='90%'><input type='text' name='category'  value='$category'  size='12'></td></tr>
		  <tr><td width='10%'>Phone     </td><td width='90%'><input type='text' name='phone'     value='$phone'     size='15'></td></tr>
		  <tr><td width='10%'>Email     </td><td width='90%'><input type='text' name='email'     value='$email'     size='80'></td></tr>
		  <tr><td width='10%'>City      </td><td width='90%'><input type='text' name='city'      value='$city'      size='25'></td></tr>
		  </table><br>
		  <table width='1024' align='center'>
		  <tr><td align='center'>
			  <input type='submit' name='task' value='Show'>
			  <input type='submit' name='task' value='Previous'>
			  <input type='submit' name='task' value='Next'>
			  <input type='submit' name='task' value='Clear'>
		  </td></tr>
		  </table>
		  <table width='1024' align='center'>
		  <tr><td width='10%'>MESSAGE: </td><td width='90%'><font color='$color'>$msg</font></td></tr>
		  </table>";
?>