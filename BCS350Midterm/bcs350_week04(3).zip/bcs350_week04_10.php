<?php
// BCS350_week04_10 - Week 4, Output the Phonebook Table - Category Dropdown
// Written by:  Prof. Kaplan, Sept. 2016

// Variables
	$pgm 			= 'bcs350_week04_10.php';
	$pgm2			= 'bcs350_week04_11.php';
	$categories 	= array('All', 'Family', 'Friend', 'Business', 'Other');
	$count 			= 0;
  
// Get Input
	if (isset($_POST['cat_in'])) $cat_in = $_POST['cat_in'];	else $cat_in = "All";
	if ($cat_in == 'All') $filter = NULL;
		else $filter = "WHERE category='$cat_in'";  

// Connect to MySQL and the BCS350 Database
	$mysqli = new mysqli('localhost', 'root', NULL, 'bcs350'); 
  
// Query the Phonebook Table
	$query = "SELECT rowid, firstname, lastname, category, phone, email, city
			  FROM phonebook
			  $filter
			  ORDER BY lastname, firstname";
	$result = mysqli_query($mysqli, $query);
  
// Output the Results
    echo "<center><b><u>My Phonebook</u></b></center><br><br>
		  <table width='1024' align='center'>
		  <tr>
		  <th width='24%'>Name</th>
		  <th width='12%'>Category</th>
		  <th width='12%'>Phone</th>
		  <th width='35%'>Email</th>
		  <th width='10%'>City</th>
		  <th width='07%'>UPDATE</th>
		  </tr>";
	while(list($rowid, $firstname, $lastname, $category, $phone, $email, $city) = mysqli_fetch_row($result)) {
		$count++;
		echo "<tr>
		      <td><a href='mailto:$email'>$firstname $lastname</a></td>
			  <td>$category</td>
			  <td>$phone</td>
			  <td>$email</td>
			  <td>$city</td>
			  <td><a href='$pgm2?r=$rowid'><button>Update</button><a></td>
			  </tr>";
		}
	echo "</table><br>
		  <table width='1024' align='center'>
		  <tr><td>$count PhoneBook Entries Found</td></tr>
		  <tr><td>&nbsp;</td></tr>
		  <tr><td><form action='$pgm' method='post'>
		  CATEGORY: <select name='cat_in'>";
	foreach ($categories as $cat) {
		if ($cat == $cat_in) $se = "SELECTED";	else $se = NULL;
		echo "<option $se>$cat</option>";
	  }
	echo "</select>
		  <input type='submit' name='submit' value='Submit'>
		  </form></td></tr></table>";
?>