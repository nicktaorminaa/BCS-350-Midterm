<?php
// BCS350_week04_01 - Week 4, Output the Phonebook Table
// Written by:  Prof. Kaplan, Sept. 2016

// Connect to MySQL and the BCS350 Database
	$mysqli = mysqli_connect('localhost', 'root', NULL, 'bcs350');
	if (!$mysqli) echo "MySQLi Connect Error: " . mysqli_connect_error();
  
// Query the Phonebook Table
	$query = "SELECT firstname, lastname, category, phone, email, city
			  FROM phonebook
			  ORDER BY lastname, firstname";
	$result = mysqli_query($mysqli, $query);
	if (!$result) echo "MySQLi Query Error: " . mysqli_error($mysqli);
  
// Output the Results
	echo "<center><b><u>My Phonebook</u></b></center><br><br>
		  <table width='1024' align='center'>
		  <tr>
		  <th width='12%'>First Name</th>
		  <th width='12%'>Last Name</th>		
		  <th width='12%'>Category</th>
		  <th width='12%'>Phone</th>
		  <th width='35%'>Email</th>
		  <th width='17%'>City</th>
		  </tr>";
	while(list($firstname, $lastname, $category, $phone, $email, $city) = mysqli_fetch_row($result)) {
		echo "<tr>
			  <td>$firstname</td>
			  <td>$lastname</td>
			  <td>$category</td>
			  <td>$phone</td>
			  <td>$email</td>
			  <td>$city</td>
			  </tr>";
		}
	echo "</table>";	
?>