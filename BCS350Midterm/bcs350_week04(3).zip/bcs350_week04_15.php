<?php
// BCS350_week04_15 - Week 4, Output the Phonebook Table - Order By Selection
// Written by:  Prof. Kaplan, Sept. 2016

// Variables
  $pgm 			= "bcs350_week04_15.php";
  $pgm2			= "bcs350_week04_12.php";  
  $count 		= 0;
  $ctgy_color	= array("Family" => "green", "Friend" => "blue", "Business" => "red", "Other" => "purple");	
  $sort_fields	= array("name", "category", "phone", "email", "city");

// Set Category Selection (WHERE) phrase
  if (isset($_POST['cat_in'])) $cat_in = $_POST['cat_in'];	else $cat_in = "All";
  if ($cat_in == "All")
	$filter = NULL;
	else $filter = "WHERE category='$cat_in'";

// Set Sort (ORDER BY) phrase
  if (isset($_POST['sort_in'])) $sort_in = $_POST['sort_in'];	else $sort_in = "name";
  switch($sort_in) {
	  case "name":		$orderby = "lastname, firstname"; break;
	  case "category":	$orderby = "category, lastname, firstname"; break;
	  case "phone":		$orderby = "phone"; break;
	  case "email":		$orderby = "email"; break;
	  case "city":		$orderby = "city, lastname, firstname"; break;
	  default:			$orderby = "lastname, firstname"; break;	  
  }  

// Connect to MySQL and the BCS350 Database
  $mysqli = new mysqli('localhost', 'root', NULL, 'bcs350'); 

// Load CATEGORIES array with Unique values from Phonebook Table
  $query =  "Select DISTINCT category FROM phonebook ORDER BY category";
  $result = $mysqli->query($query);
  $categories[] = "All";
  while(list($ctgy) = $result->fetch_row())
	$categories[] = $ctgy;
  
// Query the Phonebook Table
  $query = "SELECT rowid, firstname, lastname, category, phone, email, city
			FROM phonebook
			$filter
			ORDER BY $orderby";
  $result = $mysqli->query($query);
  
// Output the Results
  echo "<center><b><u>My Phonebook</u></b></center><br><br>
		<table width='1024' align='center'>
		<tr>
		<th width='24%'>Name</th>
		<th width='12%'>Category</th>
		<th width='12%'>Phone</th>
		<th width='30%'>Email</th>
		<th width='17%'>City</th>
		<th width='5%'>&nbsp;</th>
		</tr>";
  while(list($rowid, $firstname, $lastname, $category, $phone, $email, $city) = $result->fetch_row()) {
    $count++;
	$color = $ctgy_color[$category];
	echo "<tr>
		  <td><a href='mailto:$email'>$firstname $lastname</a></td>
		  <td><font color='$color'>$category</font></td>
		  <td>$phone</td>
		  <td>$email</td>
		  <td>$city</td>
		  <td><a href='$pgm2?r=$rowid'><button>UPDATE</button></a></td>
		  </tr>";
	}
  echo "</table><br>
		<table width='1024' align='center'>
		<tr><td>$count PhoneBook Entries Found</td></tr>
		<tr><td>&nbsp;</td></tr>
		<tr><td><form action='$pgm' method='post'>
		CATEGORY: <select name='cat_in'>";
  foreach ($categories as $cat) {
	  if ($cat == $cat_in) $se = "SELECTED";	else $se = NULL;
	  echo "<option $se>$cat</option>";
	  }
  echo "</select>&nbsp;&nbsp;  
		SORT BY <select name='sort_in'>";
  foreach ($sort_fields as $sort) {
	  if ($sort == $sort_in) $se = "SELECTED";	else $se = NULL;
	  echo "<option $se>$sort</option>";
	  }
  echo "</select>
		<input type='submit' name='submit' value='Submit'>
		</form></td></tr></table>";
  
?>