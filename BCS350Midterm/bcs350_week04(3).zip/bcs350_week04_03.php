<?php
// BCS350_week04_01 - Week 4, Output the Phonebook Table
// Written by:  Prof. Kaplan, Sept. 2016

// Connect to MySQL and the BCS350 Database
	$mysqli = new mysqli('localhost', 'root', NULL, 'bcs350')
		OR DIE(mysqli_error()); 
  
// Query the Phonebook Table
	$query = "SELECT firstname, lastname, category, phone, email, city
			  FROM phonebook
			  ORDER BY lastname, firstname";
	$result = mysqli_query($mysqli, $query);
  
// Output the Results
	echo "<center><b><u>My Phonebook</u></b></center><br><br>
		  <table width='1024' align='center'>
		  <tr>
		  <th width='12%'>Name</th>	
		  <th width='12%'>Category</th>
		  <th width='12%'>Phone</th>
		  <th width='35%'>Email</th>
		  <th width='17%'>City</th>
		  </tr>";
	while(list($firstname, $lastname, $category, $phone, $email, $city) = mysqli_fetch_row($result)) {
		echo "<tr>
			  <td><a href='mailto:$email'>$firstname $lastname</a></td>
			  <td>$category</td>
			  <td>$phone</td>
			  <td>$email</td>
			  <td>$city</td>
			  </tr>";
		}
	echo "</table>";	
?>