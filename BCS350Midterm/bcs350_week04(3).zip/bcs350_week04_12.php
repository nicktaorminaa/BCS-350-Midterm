<?php
// BCS350_week04_12 - Week 4, Update the Phonebook Table - Add, Delete
// Written by:  Prof. Kaplan, Sept. 2016

// Variables
	$pgm		= "bcs350_week04_12.php";
	$pgm2		= "bcs350_week04_13.php";	
	$categories	= array("Family", "Friend", "Business", "Other");
	$msg 		= NULL;
	$color		= "black";
	
// Get Input
	if (isset($_POST['task']))		$task = $_POST['task'];					else $task = "First";
	if (isset($_GET['r']))			{$rowid = $_GET['r']; $task = "Show";}	else $rowid = NULL;
	if (isset($_POST['rowid']))		$rowid = $_POST['rowid'];
	if (isset($_POST['firstname']))	$firstname = trim($_POST['firstname']);	else $firstname = NULL;
	if (isset($_POST['lastname']))	$lastname = trim($_POST['lastname']);	else $lastname = NULL;	
	if (isset($_POST['category']))	$category = trim($_POST['category']);	else $category = NULL;
	if (isset($_POST['phone']))		$phone = trim($_POST['phone']);			else $phone = NULL;
	if (isset($_POST['email']))		$email = trim($_POST['email']);			else $email = NULL;	
	if (isset($_POST['city']))		$city = trim($_POST['city']);			else $city = NULL;
	
// Verify Input
	if (($task != "Add") AND ($task != "Clear") AND ($task != "First")) {
		if ($rowid < 1)		$msg = "Invalid ROW ID";
		}
	if (($task == "Add") OR ($task == "Update")) {
		if ($firstname == NULL)	$msg = "First Name is missing";
		if ($lastname == NULL)	$msg = "Last Name is missing";
		if ($category == NULL)	$msg = "Category is missing";
		if ($phone == NULL)		$msg = "Phone# is missing";
		if ($email == NULL)		$msg = "Email is missing";
		if ($city == NULL)		$msg = "City is missing";
		if (!in_array($category, $categories)) $msg = "Invalid Category";
		if (!preg_match("/^[0-9]{3}-[0-9]{3}-[0-9]{4}$/", $phone)) $msg = "Invalid Phone#";
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $msg = "Invalid Email";
		}
	if ($msg != NULL)		$task = "Error";

// Connect to MySQL and the BCS350 Database
	$mysqli = new mysqli('localhost', 'root', NULL, 'bcs350');
	
// Execute Task
	switch($task) {
		case "Clear":		$rowid = $firstname = $lastname = $category = $phone = $email = $city = NULL;
		case "First":		$msg = "Enter ROW ID and press Submit"; break;
		case "Error":		$color = "red"; break;
		case "Previous":
		case "Next":
		case "Show":		if ($task == "Previous") $rowid--;
							if ($task == "Next") $rowid++;
							$query = "SELECT firstname, lastname, category, phone, email, city FROM phonebook WHERE rowid='$rowid'";
							$result = $mysqli->query($query);
							if ($result->num_rows === 0) {
								$msg = "ROW ID $rowid NOT FOUND"; 
								$color = "red";
								$firstname = $lastname = $category = $phone = $email = $city = NULL;
								}
							else {
								list($firstname, $lastname, $category, $phone, $email, $city) = $result->fetch_row();
								$msg = "ROW ID $rowid found";
								}
							break;
		case "Add":			$query = "INSERT INTO phonebook SET
									  firstname	= '$firstname',
									  lastname	= '$lastname',
									  category	= '$category',
									  phone		= '$phone',
									  email		= '$email',
									  city		= '$city'";
							$result = $mysqli->query($query);
							if ($result) {$rowid = $mysqli->insert_id; $msg = "ROW ID $rowid Added";}
								else {$msg = "ROW ID $rowid NOT Added" . mysqli_error(); $color = "red";}
							break;
		case "Update":		$query = "UPDATE phonebook SET
									  firstname	= '$firstname',
									  lastname	= '$lastname',
									  category	= '$category',
									  phone		= '$phone',
									  email		= '$email',
									  city		= '$city'
									  WHERE rowid = '$rowid'";
							$result = $mysqli->query($query);
							if ($result) $msg = "ROW ID $rowid Updated";
								else {$msg = "ROW ID $rowid NOT Updated" . mysqli_error(); $color = "red";}
							break;
		case "Delete":		$query = "DELETE FROM phonebook WHERE rowid = '$rowid'";
							$result = $mysqli->query($query);		
							if ($result) $msg = "ROW ID $rowid Deleted";
								else {$msg = "ROW ID $rowid NOT Deleted" . mysqli_error(); $color = "red";}
							break;
		default:			$msg = "Invalid Task"; $color = "red"; break;
		}
		
// Output the Results
	echo "<center><b><u>My Phonebook Update</u></b></center><br><br>
		  <form action='$pgm' method='post'>
		  <table width='1024' align='center'>
		  <tr><td width='10%'>ROW ID    </td><td width='90%'><input type='text' name='rowid'     value='$rowid'     size='08'></td></tr>
		  <tr><td width='10%'>First Name</td><td width='90%'><input type='text' name='firstname' value='$firstname' size='25'></td></tr>
		  <tr><td width='10%'>Last Name </td><td width='90%'><input type='text' name='lastname'  value='$lastname'  size='25'></td></tr>
		  <tr><td width='10%'>Category  </td><td width='90%'><select name='category'>";
	foreach ($categories as $cat) {
		if ($cat == $category) $se = "SELECTED"; else $se = NULL;
		echo "<option $se>$cat</option>";
		}
	echo "</select></td></tr>
		  <tr><td width='10%'>Phone     </td><td width='90%'><input type='text' name='phone'     value='$phone'     size='15'></td></tr>
		  <tr><td width='10%'>Email     </td><td width='90%'><input type='text' name='email'     value='$email'     size='80'></td></tr>
		  <tr><td width='10%'>City      </td><td width='90%'><input type='text' name='city'      value='$city'      size='25'></td></tr>
		  </td></td></table><br>
		  <table width='1024' align='center'>
		  <tr><td align='center'>
			  <input type='submit' name='task' value='Show'>
			  <input type='submit' name='task' value='Add'>
			  <input type='submit' name='task' value='Update'>
			  <input type='submit' name='task' value='Delete'>			  
			  <input type='submit' name='task' value='Clear'>
			  <input type='submit' name='task' value='Previous'>
			  <input type='submit' name='task' value='Next'>
		  </td></tr>
		  </table>
		  <table width='1024' align='center'>
		  <tr><td width='10%'>MESSAGE: </td><td width='90%'><font color='$color'>$msg</font></td></tr>
		  </table></form>
		  <table width='1024' align='center'
		  <tr><td align='center'><a href='$pgm2'><button>Return to Phone List</button></a></td></tr>
		  </table>";
?>